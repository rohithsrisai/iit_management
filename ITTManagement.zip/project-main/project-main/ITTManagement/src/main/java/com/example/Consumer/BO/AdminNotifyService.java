package com.example.Consumer.BO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.AdminNotifyDaoImpl;


@Service
public class AdminNotifyService {
	
	@Autowired
	AdminNotifyDaoImpl adminNotifyDaoImpl;

	public Boolean adminnotification(int ticketId , String empId, String selectRemedy, String information, String Requestdocument, String ticketStatus) {
	return adminNotifyDaoImpl.adminnotification(ticketId ,empId,selectRemedy, information,Requestdocument, ticketStatus);
}
	
	
}
