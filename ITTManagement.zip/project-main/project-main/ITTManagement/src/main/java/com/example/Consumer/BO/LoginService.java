package com.example.Consumer.BO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.LoginDaoImpl;

import com.example.Consumer.Model.RaiseGsd;

@Service
public class LoginService {
	@Autowired
	LoginDaoImpl loginDaoImpl;

	public Boolean validate1(String userId, String password) {
		String pwd = loginDaoImpl.getPassword1(userId);
		if (pwd != null && pwd.equals(password))
			return true;
		return false;
	}

	public Boolean validate(String empid, String password) {
		String pwd = loginDaoImpl.getPassword(empid);
		if (password.equals(pwd))
			return true;
		return false;
	}

	public String getPcNumber(String empId) {
		return loginDaoImpl.getPcno(empId);
	}

	public String getContactNumber(String empId) {
		return loginDaoImpl.getContactno(empId);
	}

	public String getEmpId(String empId) {
		return loginDaoImpl.getEmpId(empId);
	}

	public List<RaiseGsd> getAllRequests() {
		return loginDaoImpl.getAllRequests();
	}

	public RaiseGsd getDetails(String id) {
		return loginDaoImpl.getDetailsById(id);
	}

}
