package com.example.Consumer.BO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.RaiseGsdDaoImpl;

@Service
public class RaiseGsdService {
	@Autowired
	RaiseGsdDaoImpl remedyDaoImpl;

	public Boolean remedyUser(String selectRemedy, String description1,String contactNo,String pcno,String empId){
		
		return remedyDaoImpl.remedyUser(selectRemedy,description1,contactNo,pcno,empId);
	}

}
