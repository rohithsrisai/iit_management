package com.example.Consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Consumer.BO.AdminNotifyService;


@Controller
public class AdminNotifyController {

	@Autowired
	AdminNotifyService adminNotifyService;
	
	
	@RequestMapping(value = "/adminnotification", method = RequestMethod.POST)
	public String adminnotification(@RequestParam int ticketId ,@RequestParam String empId,@RequestParam String selectRemedy,@RequestParam String information,@RequestParam String Requestdocument,@RequestParam String ticketStatus) {
		if(adminNotifyService.adminnotification(ticketId ,empId,selectRemedy, information,Requestdocument, ticketStatus)) {
			return "index";
		}
		
		return "adminnotify";
	}
	
}