package com.example.Consumer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Consumer.BO.LoginService;
import com.example.Consumer.Model.RaiseGsd;

@Controller
public class LoginController {
	@Autowired
	LoginService loginService;


	@RequestMapping(value = "/userlogin", method = RequestMethod.GET)
	public String loginUser() {

		return "userlogin";
	}

	
	@RequestMapping(value = "/adminlogin", method = RequestMethod.GET)
	public String admin() {

		return "adminlogin";
	}
	
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String home() {
		return "index";
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String back() {
		return "index";
	}

	


	@RequestMapping(value = "/fileupload", method = RequestMethod.GET)
	public String changePC() {

		return "fileupload";
	}

	
	 @RequestMapping(value = "/details", method = RequestMethod.GET)
	 public String ticketDetails(@RequestParam String id,ModelMap model) {
//		 System.out.println(id);
	  model.addAttribute("ticketDetails", loginService.getDetails(id));
	 return "details"; }
	 
	@RequestMapping(value = "/resolve", method = RequestMethod.GET)
	public String ticketResolve() {

		return "resolve";
	}

	@RequestMapping(value = "/adminnotify", method = RequestMethod.POST)
	public String admindashboard1(@RequestParam String myInput, @RequestParam String password, ModelMap map) {
		Boolean valid = loginService.validate1(myInput, password);
		if (valid) {
			List<RaiseGsd> requests = loginService.getAllRequests();
			map.addAttribute("requests", requests);
			System.out.println(requests);
			return "/adminnotify";
		}
		return "index";
	}
	@RequestMapping(value = "/adminnotiffy", method = RequestMethod.POST)
	public String adminnotification(ModelMap map) {
		List<RaiseGsd> requests = loginService.getAllRequests();
		map.addAttribute("requests", requests);
		
		return "adminnotify";
	}

	@RequestMapping(value = "/validateUser", method = RequestMethod.POST)
	public String valiadate(@RequestParam String empId, @RequestParam String password, ModelMap map) {
		Boolean valid = loginService.validate(empId, password);
		if (valid) {

			// fetch from the db
			map.addAttribute("contact", loginService.getContactNumber(empId));
			map.addAttribute("pcNo", loginService.getPcNumber(empId));
			map.addAttribute("empId", loginService.getEmpId(empId));
			return "gsdcreate";
		}
		return "index";
	}
	@RequestMapping(value = "/usernotify", method = RequestMethod.GET)
	public String usernotification() {
			return "usernotify";
	}
	@RequestMapping(value = "/feedback", method = RequestMethod.GET)
	public String feedback() {
			return "feedback";
	}
	

}