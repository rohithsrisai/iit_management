package com.example.Consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



import com.example.Consumer.BO.RegistrationService;


@Controller
public class RegistrationController {
	
	@Autowired
	RegistrationService registrationService;
	
	
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public String registerUser(ModelMap map,@RequestParam String fname,@RequestParam String lname,@RequestParam String des,@RequestParam String empId,@RequestParam String seatno,@RequestParam String pcno,@RequestParam String ip,@RequestParam String contactNo,@RequestParam String password) {
		if(registrationService.registerUser(fname, lname, des, empId, seatno, pcno,ip,contactNo, password)) {
			return "registersuccess";
		}
		
		return "regis";
	}
	
	@RequestMapping(value = "/regis", method = RequestMethod.GET)
	public String registerCustomer() {
		return "regis";
	}


}
