package com.example.Consumer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.Consumer.BO.UserFeedbackDetailsService;
import com.example.Consumer.Model.UserFeedbackDetails;

@Controller
public class UserFeedbackDetailsController {
	@Autowired
	UserFeedbackDetailsService userFeedbackDetailsService;
	@RequestMapping(value = "/UserFeedbackDetails", method = RequestMethod.GET)
	public String UserFeedbackDetails(ModelMap map) {
		List<UserFeedbackDetails> requests = userFeedbackDetailsService.getAllRequests();
		map.addAttribute("requests", requests);
		
		return "userfeedbackdetails";
	}
}
