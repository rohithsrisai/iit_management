package com.example.Consumer.Dao;

public interface AdminNotifyDao {
	public Boolean adminnotification(int ticketId , String empId, String selectRemedy, String information, String Requestdocument, String ticketStatus);
}
