package com.example.Consumer.Dao;

public interface FeedBackDao {
	public Boolean feedback(String empId, int ticketId , String reviewdescription, String ratings);

}
