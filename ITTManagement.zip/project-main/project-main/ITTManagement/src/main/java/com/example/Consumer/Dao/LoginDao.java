package com.example.Consumer.Dao;

import java.util.List;

import com.example.Consumer.Model.RaiseGsd;

public interface LoginDao {

	public String getPassword1(String userId);
	public String getPassword(String empId);
	public String getContactno(String empid);
	public String getPcno(String empid);
	public String getEmpId(String empid);
	public List<RaiseGsd> getAllRequests(); 
	public RaiseGsd getDetailsById(String id);
	
}
