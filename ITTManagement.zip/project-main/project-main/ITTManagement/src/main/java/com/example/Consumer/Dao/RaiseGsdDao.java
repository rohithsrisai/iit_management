package com.example.Consumer.Dao;

public interface RaiseGsdDao {
	public Boolean remedyUser(String selectRemedy, String description1 , String contactNo, String pcno, String empId);
	
	
	
	
}
