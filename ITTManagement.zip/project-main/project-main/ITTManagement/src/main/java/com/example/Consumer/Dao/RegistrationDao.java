package com.example.Consumer.Dao;

public interface RegistrationDao {

	public Boolean registerUser(String fname,String lastname,String des,String empId,String seatno,String pcno,String ip,String contactNo,String password);
}

//controller -> bo ->daoimpl->datbase