package com.example.Consumer.Dao;

import com.example.Consumer.Model.AdminNotify;


public interface UserNotifyDao {

	public AdminNotify getDetailsById(String empid);

}
