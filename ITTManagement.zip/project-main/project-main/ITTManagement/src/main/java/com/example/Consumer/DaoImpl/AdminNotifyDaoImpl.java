package com.example.Consumer.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.Consumer.Dao.AdminNotifyDao;

@Component
public class AdminNotifyDaoImpl implements AdminNotifyDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public Boolean adminnotification(int ticketId , String empId, String selectRemedy, String information, String Requestdocument, String ticketStatus) {
		int flag;
		try {
			flag=jdbcTemplate.update("insert into adminnotify(ticketId,empId,selectRemedy,information,Requestdocument,ticketStatus) values(?,?,?,?,?,?)",ticketId,empId,selectRemedy,information,Requestdocument,ticketStatus);
			if(flag>0)
				return true;
		}
		catch (Exception e) {
			return true;
		}
		
		return false;
	}

}









