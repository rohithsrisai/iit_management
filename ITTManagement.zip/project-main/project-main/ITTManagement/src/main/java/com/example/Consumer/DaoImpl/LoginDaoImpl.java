package com.example.Consumer.DaoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.example.Consumer.Dao.LoginDao;
import com.example.Consumer.Model.RaiseGsd;
@Component
public class LoginDaoImpl implements LoginDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public String getPassword1(String id) {
		String password;
		try {
		
			password=jdbcTemplate.query("select * from adminreg where userId=?", new ResultSetExtractor<String>() {

				@Override
				public String extractData(ResultSet rs) throws SQLException, DataAccessException {
					rs.next();
					return rs.getString("password");
				
				}
				
			}, id);
		
		return password;}
		catch (Exception e) {
			return null;
		}
	}
	
	
	


	@Override
	public String getPassword(String empId) {
		String password=jdbcTemplate.query("select * from users where empId=?", new ResultSetExtractor<String>() {

			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				return rs.getString("password");
				
			}
			
		}, empId);
		return password;
		
	}





	@Override
	public String getContactno(String empid) {
		String contactNo;
		contactNo=jdbcTemplate.query("select * from users where empId=?", new ResultSetExtractor<String>() {

			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				return rs.getString("contactNumber");
			}
			
		}, empid);
		return contactNo;
	}





	@Override
	public String getPcno(String empid) {
		String pcNo;
		pcNo=jdbcTemplate.query("select * from users where empId=?", new ResultSetExtractor<String>() {

			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				//System.out.println(rs.getString("pcNumber"));
				return rs.getString("pcNumber");
			}
			
		}, empid);
		return pcNo;
		
	}
	
	@Override
	public String getEmpId(String empid) {
		String Empid;
		Empid=jdbcTemplate.query("select * from users where empId=?", new ResultSetExtractor<String>() {

			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				return rs.getString("empId");
			}
			
		}, empid);
		return Empid;
	}





	@Override
	public List<RaiseGsd> getAllRequests() {
		List<RaiseGsd> RaiseGsdList=jdbcTemplate.query("select * from raisegsd", new RowMapper<RaiseGsd>() {

			@Override
			public RaiseGsd mapRow(ResultSet rs, int rowNum) throws SQLException {
				RaiseGsd rg=new RaiseGsd();
				rg.setSelectRemedy(rs.getString("selectRemedy"));
				rg.setDescription1(rs.getString("description1"));
				rg.setContactNumber(rs.getString("contactNumber"));
				rg.setPcNumber(rs.getString("pcNumber"));
				rg.setGsdnuber(rs.getInt("gsdnumber"));
				rg.setEmpId(rs.getString("empId"));
				
				return rg;
			}	
			
		});
		return RaiseGsdList;
	}





	@Override
	public RaiseGsd getDetailsById(String id) {
		RaiseGsd rgsd;
		rgsd=jdbcTemplate.query("select * from raisegsd where gsdnumber=?", new ResultSetExtractor<RaiseGsd>() {

			@Override
			public RaiseGsd extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				RaiseGsd r=new RaiseGsd();
				r.setGsdnuber(rs.getInt("gsdnumber"));
				r.setSelectRemedy(rs.getString("selectRemedy"));
				r.setDescription1(rs.getString("description1"));
				r.setContactNumber(rs.getString("contactNumber"));
				r.setPcNumber(rs.getString("pcNumber"));
				r.setEmpId(rs.getString("empId"));
				
				return r;
			}	
			
		}, id);
		return rgsd;
	}

}
