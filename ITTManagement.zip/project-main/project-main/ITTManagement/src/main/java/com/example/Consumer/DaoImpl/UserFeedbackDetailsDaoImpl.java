package com.example.Consumer.DaoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.example.Consumer.Dao.UserFeedbackDetailsDao;

import com.example.Consumer.Model.UserFeedbackDetails;

@Component
public class UserFeedbackDetailsDaoImpl implements UserFeedbackDetailsDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	

	@Override
	public List<UserFeedbackDetails> getAllRequests() {
		List<UserFeedbackDetails> UserFeedbackDetailsList=jdbcTemplate.query("select * from review", new RowMapper<UserFeedbackDetails>() {

			@Override
			public UserFeedbackDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				UserFeedbackDetails fd=new UserFeedbackDetails();
				fd.setEmpId(rs.getString("empId"));
				fd.setTicketId(rs.getInt("ticketId"));
				fd.setReviewdescription(rs.getString("reviewdescription"));
				fd.setRatings(rs.getString("ratings"));
				
				return fd;
			}	
			
		});
		return UserFeedbackDetailsList;
	}



	
	

}
