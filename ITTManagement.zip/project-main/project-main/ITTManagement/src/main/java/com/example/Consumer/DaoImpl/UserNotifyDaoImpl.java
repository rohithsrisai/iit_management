package com.example.Consumer.DaoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import com.example.Consumer.Dao.UserNotifyDao;
import com.example.Consumer.Model.AdminNotify;



@Component
public class UserNotifyDaoImpl implements UserNotifyDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public AdminNotify getDetailsById(String empid) {
		AdminNotify anotify;
		anotify=jdbcTemplate.query("select * from adminnotify where empId=?", new ResultSetExtractor<AdminNotify>() {

			@Override
			public AdminNotify extractData(ResultSet rs) throws SQLException, DataAccessException {
				rs.next();
				AdminNotify a=new AdminNotify();
				a.setTicketId(rs.getInt("ticketId"));
				a.setEmpId(rs.getString("empId"));
				a.setSelectRemedy(rs.getString("selectRemedy"));
				a.setInformation(rs.getString("information"));
				a.setRequestdocument(rs.getString("Requestdocument"));
				a.setTicketStatus(rs.getString("ticketStatus"));
				
				return a;
			}	
			
		}, empid);
		return anotify;
	}

}

